package br.com.Exercicio9;

public class ExercicioMod9 {
	
	public static void main(String[] args) {
   
	    // Primitivo 	
		long cpf = 12405876212l;
		
		
        // Wrapper
		
		Long cpfCliente = cpf;
		
		System.out.println("CPF do Cliente: " + cpf); 
		
		
		
		
		
		
		
		
		
       
      
       
}
		
	}

          